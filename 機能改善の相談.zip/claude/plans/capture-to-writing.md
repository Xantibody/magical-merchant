# Capture-to-writing friction: implementation plan

Approved direction (2026-08-16). Mocks: Improvements.dc.html (ids 2a, 2b, 1c, 1d, 1e).
Order below = recommended implementation order. Each phase ships independently;
run `just verify` and check mobile layout in `just tauri_app::dev-browser` before closing.

## Phase 1 — 2a: Tap-to-edit whole note + explicit save

Fixes: "モバイルで編集しづらい" issue.

- Remove the pencil entry point: tapping/clicking anywhere in `.detail-body`
  (preview) calls `startEditing`; place the cursor at the tap point via
  ProseMirror `posAtCoords` after the lazy editor mounts
- Replace the 1s-debounce autosave (`update_draft`) with explicit save:
  - Header button 保存 (and ⌘S) → `flushSave`
  - Back/navigation with `draft !== noteBody` → inline confirm bar 保存 / 破棄
  - No changes → return to preview silently (accidental taps cost nothing)
- MarkdownToolbar: dock above the keyboard, tracking `visualViewport.height`;
  keep `--safe-bottom` from base.css (never raw env())
- Keep the serialized save chain; `stopEditing` still refetches the list once
- Tests: layout.test conventions if bar positions are asserted; add unit test
  for the dirty-check (draft === body → no confirm)

## Phase 2 — 2b: Promote entry → note, linked both ways

- Timeline entry action (long-press mobile / hover PC): ノートにする
  - `create_draft(body=entry.text, tags=parsed tags)` then open it editing
    via existing `?file=` route
- Origin link: new frontmatter key `origin` (ISO datetime of the entry)
  - MUST be a typed field on `NoteFrontmatter` in Rust core (unknown keys are
    dropped on save). Omit when unset so untouched notes stay byte-identical
  - Syncs with the note; no timeline file format change
- Timeline side chip (📄 note title →) is **derived**: when rendering a day,
  overlay notes whose `origin` falls on that day — avoids entry-index drift
- Chips jump via existing routes (`?file=`, extraDates + data-day scroll)
- ipc-mock: add/extend handlers for any new/changed commands
- Later (optional): manual link from NoteMetaPopover

## Phase 3 — 1c: Palette zero-query + precise landing

- Zero-query state: 最近 (head of `list_notes`), タグ (countTags), 日付
  (今日/昨日 from `list_timeline_dates`) — no new IPC
- `onSelectHit`: land exactly — notes via `?file=`, timeline hits by adding the
  date to `extraDates` and scrolling to `[data-day]` (existing jumpTo path)
- Core: extend `search_all` snippet with match offsets + surrounding context
- Keep 200ms debounce and `isImeComposing` Enter guard

## Phase 4 — 1d: [[links]] + backlinks

- Stored form `[[YYYYMMDD_HHMMSS]]` (filename = immutable ID → rename-proof);
  rendered as resolved title
- Milkdown: one custom inline node + autocomplete popup only while typing `[[`
  (no persistent chrome; rejected-plugin list stays rejected)
- Backlinks: derived at read time by scanning (reuse search_all); no index, no
  frontmatter changes. Collapsible footer リンクされている記録 in note view
- MCP: consider exposing backlinks as a read-only tool later

## Phase 5 — 1e: Weekly digest card

- Injected at top of Timeline once per week (dismissable); aggregation only
  (`read_timeline_by_date` + countTags), no core changes
- Show-once/dismiss state in local settings — never in data files
- 1年前の今日: only when `list_timeline_dates` has the date

## Out of scope / guardrails

- No Tasks mode. No new visible chrome beyond the above
- Storage invariants (filename ID, verbatim frontmatter, editor sees body only)
  and sync rules per .claude/skills/sync-storage/SKILL.md
